from flask import Flask,render_template,url_for,request

app = Flask(__name__)


@app.route('/')
def index():
    return 'this is index'

@app.route('/admin')
def admin():
    return render_template('admin.html')


@app.route('/login',methods=['POST', 'GET'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    if request.method == 'POST':
        return  render_template('admin.html')


    return render_template('login.html')


if __name__ == '__main__':
    app.run(debug=True)
