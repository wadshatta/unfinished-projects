from distutils.log import debug
from flask import Flask,render_template ,request,url_for
from flask_mysqldb import MYSQL

app = Flask(__name__)
app.secret_key = 'sercret_key'

app.config['MYSQL_HOST'] ='localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'curd'

mysql = MYSQL(app)


@app.route('/')
def Index():
    cur = mysql.connection.cursor()
    cur.execute('  SELECT * FROM  students')
    data.cur.fetchall()
    cur.close()
    return render_template('index.html',students=data)

if __name__ == "__main__":
    app.run(debug=True)    