from flask import Flask ,render_template,request
from flaskext.mysql import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_HOST'] = ''
app.config['MYSQL_HOST'] = 'flask'

mysql = MYSQL(app)

cursor = mysql.connection.cursor()
cursor.execute('INSER INTO user VALUES(fox,fox@app.com)')
mysql.connection.commit()

cursor.close()