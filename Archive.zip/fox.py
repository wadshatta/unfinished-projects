from flask import Flask, render_template

Skills_app = Flask(__name__)


@Skills_app.route("/")
def homepage():
    return render_template('homepage.html',pagetitle="this is homePage")


@Skills_app.route("/about")
def about():
    return render_template("about.html",pagetitle='this is about')



if __name__ == "__main__":

    Skills_app.run(debug=True)       