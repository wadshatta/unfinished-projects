from flask import Flask,render_template,request,session,redirect,g,url_for
import os

from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ""
app.config['MYSQL_DB'] = 'company'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)






@app.route('/',methods=['GET','POST'])
def index():

    if request.method == "POST":
        name = request.form['name']
        email = request.form['email']

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO user (name,email) VALUES(%s,%s)",(name,email))

        mysql.connection.commit()
        cur.close()


        return "success"




    return render_template('index.html')




@app.route('/users')
def users():
    cur = mysql.connection.cursor()
    users = cur.execute('SELECT * FROM user')
    if users > 0:
        userDetails = cur.fetchall()

        return render_template('users.html',userDetails = userDetails)



if __name__ == "__main__":
    app.run(debug=True)
